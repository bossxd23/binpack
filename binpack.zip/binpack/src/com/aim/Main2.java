package com.aim;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * The Main class is responsible for loading data from a file 
 * and performing Tabu Search on dataset found in the file.
 */
public class Main {
    public static void main(String[] args) {
        
        // Load all datas
        List<Data> datas = loadData("BPP.txt");
        
        // Perform Tabu Search on specific data sets and display results
        for (int i = 0; i < 5; i++) {  // Assuming there are at least 5 data sets
            Data testingData = datas.get(i);
            System.out.println("Performing Tabu Search on " + testingData.getTestName() + " data.\n");
            TabuSearch tabu = new TabuSearch(testingData.getItems(), testingData.getBinCapacity());
            
            System.out.println("Tabu Search Results:");
            tabu.showSolution();
        }
    }
    
    /**
     * Loads data from a file and creates Data objects for each dataset found in the file.
     *
     * @param filePath The path to the file containing the data.
     * @return A list of Data objects representing each dataset.
     */
    private static List<Data> loadData(String filePath) {
        List<Data> datas = new ArrayList<>();
        
        try {
            File file = new File(filePath);
            Scanner scanner = new Scanner(file);
            
            while (scanner.hasNext()) {
                String name = scanner.next();
                int numWeights = scanner.nextInt();
                int capacity = scanner.nextInt();
                
                List<Item> items = new ArrayList<>();
                for (int i = 0; i < numWeights; i++) {
                    int weight = scanner.nextInt();
                    int count = scanner.nextInt();
                    items.add(new Item(weight, count));
                }
                
                // create object for each data set
                Data data = new Data(name, capacity, items);
                datas.add(data);
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.err.println("File not found!");
        }
        
        return datas;
    }
}
