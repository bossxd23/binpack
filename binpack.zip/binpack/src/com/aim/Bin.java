package com.aim;

import java.util.ArrayList;
import java.util.List;

/**
 * Bin class is use for solving
 * bin packing problems
 */
public class Bin {
	private List<Item> items;
    private int capacity;

    /**
     * Constructs a bin with a specified capacity.
     * 
     * @param capacity The capacity of the bin.
     */
    public Bin(int capacity) {
        this.capacity = capacity;
        this.items = new ArrayList<>();
    }
    
    /**
     * Constructs a copy of the given bin.
     * 
     * @param binToCopy The bin to copy.
     */
    public Bin(Bin binToCopy) {
        this.items = new ArrayList<>(binToCopy.getItems());
        this.capacity = binToCopy.getCapacity();
    }
    
    /**
     * Creates a copy of the current bin.
     * 
     * @return A new bin that is a copy of the current one.
     */
    public Bin copy() {
        return new Bin(this);
    }

    /**
     * Adds an item to the bin if there is enough capacity.
     * 
     * @param item The item to add to the bin.
     * @return True if the item was successfully added, false otherwise.
     */
    public boolean addItem(Item item) {
//    	System.out.println(getRemainingCapacity() + " size remain.");
//    	System.out.println(item.getTotalWeight() + " to be inserted.");'
    	// ❗Remember that total weight of item need to be considered
    	// not just one weight, but weight and how many there are
        if (getRemainingCapacity() >= item.getTotalWeight()) {
            items.add(item);
            return true;
        }
        return false;
    }

    /**
     * Removes an item from the bin.
     * 
     * @param item The item to remove from the bin.
     * @return True if the item was successfully removed, false otherwise.
     */
    public boolean removeItem(Item item) {
        return items.remove(item);
    }

    /**
     * Checks if the bin is empty.
     * 
     * @return True if the bin is empty, false otherwise.
     */
    public boolean isEmpty() {
        return items.isEmpty();
    }

    /**
     * Gets the remaining capacity of the bin.
     * 
     * @return The remaining capacity of the bin.
     */
    public int getRemainingCapacity() {
        return capacity - getTotalWeight();
    }

    /**
     * Gets the items in the bin.
     * 
     * @return The list of items in the bin.
     */
    public List<Item> getItems() {
        return items;
    }

    /**
     * Gets the capacity of the bin.
     * 
     * @return The capacity of the bin.
     */
    public int getCapacity() {
        return capacity;
    }
    
    /**
     * Calculates the total weight of all items in the bin.
     * 
     * @return The total weight of all items in the bin.
     */
    public int getTotalWeight() {
    	return items.stream().mapToInt(i -> i.getTotalWeight()).sum();
    }
}
