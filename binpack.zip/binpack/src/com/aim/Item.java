package com.aim;

/**
 * Item class represent an item of bin packing problem
 * with a weight and count.
 */
public class Item {
	private int weight;
    private int count;

    /**
     * Constructs an Item object with the specified weight and count.
     * 
     * @param weight The weight of the item.
     * @param count  The count of the item.
     */
    public Item(int weight, int count) {
        this.weight = weight;
        this.count = count;
    }

    /**
     * Gets the weight of the item.
     * 
     * @return The weight of the item.
     */
	public int getWeight() {
		return weight;
	}

	/**
     * Gets the count of the item.
     * 
     * @return The count of the item.
     */
	public int getCount() {
		return count;
	}
	
	/**
     * Calculates the total weight of the item (weight * count).
     * 
     * @return The total weight of the item.
     */
	public int getTotalWeight() {
		return weight * count;
	}
}
