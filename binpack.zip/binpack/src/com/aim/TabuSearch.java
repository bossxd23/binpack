package com.aim;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * TabuSearch class implements the Tabu Search algorithm for the Bin Packing Problem.
 */
public class TabuSearch {
	// solution
	private List<Bin> bins = new ArrayList<>(); // store best solution
	/**
	 * The tabuList in Tabu Search is used to store the history of solutions 
	 * that have been explored recently. The main purpose is to prevent the 
	 * algorithm from revisiting previously explored solutions within a 
	 * certain number of iterations, known as the tabu tenure.
	 */
	private List<Bin> tabuList = new ArrayList<>(); // history of solution
	
	// Tabu configurations
	private List<Item> items;	// original test data
	private int binCapacity;	// bin capacity
	private int maxIterations = 10;	// stop condition
	private int tabuTenure = 10;	// exploration iteration
	
	/**
     * Constructor for TabuSearch class.
     * @param items The list of items to be packed.
     * @param capacity The capacity of each bin.
     */
	public TabuSearch(List<Item> items, int capacity) {
		// 0- set tabu configurations
		this.items = items;
		this.binCapacity = capacity;
		
		
		// 1- generate initial solution ================================
		this.bins = initialSolution();
		
		System.out.println("Initial solution with bin capacity of " + binCapacity + ".\n");
		printSolution(bins);
		
		
		// track iteration number
		int currentIteration = 0;
		
		// initialise best solution with initial solution
        List<Bin> bestSolution = new ArrayList<>(bins);
        // number value - quality of solution
        int bestFitness = objectiveFunction(bins);        
        
        System.out.println("\n+++++++++ Tabu Search +++++++++\n");
        
		while (currentIteration < maxIterations) {
			// 2- generate neighbourhood solution ================================
            List<List<Bin>> neighbors = generateNeighbors(bins);
            
//            int neighborIteration = 1;
//            for(List<List<Item>> neighbor : neighbors) {
//            	System.out.println("Neighbors " + neighborIteration++ + ": ");
//            	printSolution(neighbor);
//            }
//            
			// 3- evaluate solution, choose the best solution
            // Find the best neighbor solution
            List<Bin> bestNeighbor = findBestNeighbor(neighbors);
            int bestNeighborFitness = objectiveFunction(bestNeighbor);

            // Update tabu list
            tabuList.addAll(bestNeighbor);
            if (tabuList.size() > tabuTenure) {
                tabuList.remove(0);
            }

            // Update current solution
            bins = bestNeighbor;
			
			// 4- update best solution so far
            if (bestNeighborFitness < bestFitness) {
                bestSolution = new ArrayList<>(bestNeighbor);
                bestFitness = bestNeighborFitness;
            }
			
			// 5- repeat steps until stop condition satisfied
			currentIteration++;
		}
	}
	
	/**
     * Prints the solution (list of bins) to the console.
     */
	public void showSolution() {
		printSolution(bins);
	}
	
	/**
     * Generates the initial solution using the First Fit decreasing algorithm.
     * @return The initial solution as a list of bins.
     */
	private List<Bin> initialSolution() {
		
		// prepare empty bins
		List<Bin> bins = new ArrayList<>();
		
		// Sort items in decreasing weight
        items.sort(Comparator.comparingInt(Item::getWeight).reversed());
        
		// loop through each item
		for (Item item : items) {
			// keep track if item is packed
            boolean packed = false;
            
            // will try to insert item on each bin
            for (Bin bin : bins) {
            	// item successfully inserted into bin
                if (bin.addItem(item)) {
                    packed = true;
                    break;
                }
            }
            // cannot pack item
            if (!packed) {
            	// create a new bin
                Bin newBin = new Bin(binCapacity);
                newBin.addItem(item);
                bins.add(newBin);
            }
        }
        return bins;
		
	}
	
	/**
     * Generates neighboring solutions by moving items between bins.
     * @param bins The current solution as a list of bins.
     * @return List of neighboring solutions.
     */
	private List<List<Bin>> generateNeighbors(List<Bin> bins) {
	    List<List<Bin>> neighbors = new ArrayList<>();
	    for (int i = 0; i < bins.size(); i++) {
	        for (int j = 0; j < bins.size(); j++) {
	            if (i != j) {
	                // Create a copy of the current solution
	                List<Bin> newBins = copyBins(bins);
	                Bin fromBin = newBins.get(i);
	                Bin toBin = newBins.get(j);
	                if (!fromBin.isEmpty()) {
	                    // Move the first item from one bin to another
	                	Item itemToMove = fromBin.getItems().get(0);
	                	fromBin.removeItem(itemToMove);
                        toBin.addItem(itemToMove);
	                    // Add the modified solution to the neighbors list
                        neighbors.add(newBins);
	                }
	            }
	        }
	    }
	    return neighbors;
	}
	
	/**
     * Copies a list of bins.
     * @param binsToCopy The list of bins to copy.
     * @return A copy of the list of bins.
     */
	public static List<Bin> copyBins(List<Bin> binsToCopy) {
        List<Bin> copiedBins = new ArrayList<>();
        for (Bin bin : binsToCopy) {
            copiedBins.add(bin.copy());
        }
        return copiedBins;
    }

	/**
     * Finds the best neighbor solution from a list of neighboring solutions.
     * @param neighbors The list of neighboring solutions.
     * @return The best neighbor solution.
     */
    private List<Bin> findBestNeighbor(List<List<Bin>> neighbors) {
        List<Bin> bestNeighbor = null;
        int bestNeighborFitness = Integer.MAX_VALUE;
        for (List<Bin> neighbor : neighbors) {
            if (!isTabu(neighbor)) {
                int fitness = objectiveFunction(neighbor);
                if (fitness < bestNeighborFitness) {
                    bestNeighbor = neighbor;
                    bestNeighborFitness = fitness;
                }
            }
        }
        return bestNeighbor;
    }

    /**
     * Checks if a solution is in the tabu list.
     * @param solution The solution to check.
     * @return True if the solution is in the tabu list, otherwise false.
     */
    private boolean isTabu(List<Bin> solution) {
        return tabuList.contains(solution);
    }
	
	/**
	 * The objective function evaluates the quality of solution.
	 * Evaluates the fitness of a solution (number of bins used).
	 * @param bins The solution as a list of bins.
     * @return The fitness value of the solution.
	 */
	private int objectiveFunction(List<Bin> bins) {
		return bins.size();
	}
	
	/**
     * Prints the solution (list of bins) to the console.
     * @param bins The solution as a list of bins.
     */
	private void printSolution(List<Bin> bins) {		
		int binNumber = 1;
		for(Bin bin : bins) {
			System.out.println("Bin " + binNumber++ + " (" + bin.getTotalWeight() + ")");
			for(Item item : bin.getItems()) {
				System.out.println(
						"Weight: " + item.getWeight() + 
						", Count: " + item.getCount());
				
			}
		}
		System.out.println("\nFitness value: " + objectiveFunction(bins));	
	}
	
	/**
	 * Prints the weight and count of each item in a list.
	 * 
	 * @param items The list of items to be printed.
	 */
	private void printItems(List<Item> items) {
		for(Item item : items) {
			System.out.println(
					"Weight: " + item.getWeight() + 
					", Count: " + item.getCount());
			
		}
	}
    
}
