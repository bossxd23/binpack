package com.aim;

import java.util.List;

/**
 * Data class is mainly use for reading data from file text
 */
public class Data {
	private String testName;
	private int binCapacity;
	private List<Item> items;

	/**
     * Constructs a Data object
     * 
     * @param name      The name of the test.
     * @param capacity  The capacity of the bins.
     * @param items     The list of items.
     */
    public Data(String name, int capacity, List<Item> items) {
        this.testName = name;
        this.binCapacity = capacity;
        this.items = items;
    }
    
    /**
     * Displays information about the data.
     */
    public void display() {
    	System.out.println("Test name: " + testName);
        System.out.println("Capacity of the bins: " + binCapacity);
        System.out.println("Item weights (" + items.size() + ") : ");
        for (Item item : items) {
            System.out.println(item.getWeight() + " - " + item.getCount());
        }
    }
    
    /**
     * Gets the name of the test.
     * 
     * @return The name of the test.
     */
    public String getTestName() {
    	return this.testName;
    }
    
    /**
     * Gets the capacity of the bins.
     * 
     * @return The capacity of the bins.
     */
    public int getBinCapacity() {
    	return this.binCapacity;
    }
    
    /**
     * Gets the list of items.
     * 
     * @return The list of items.
     */
    public List<Item> getItems() {
    	return this.items;
    }
}